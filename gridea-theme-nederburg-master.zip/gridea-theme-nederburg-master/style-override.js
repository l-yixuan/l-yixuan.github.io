const generateOverride = (params = {}) => {
  let result = ''

  return result
}

module.exports = generateOverride
