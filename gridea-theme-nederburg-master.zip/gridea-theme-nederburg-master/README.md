# Nederburg theme for Gridea

Nederburg is a fast and beautiful theme.

This Gridea theme was ported from [competethemes](https://www.competethemes.com/tracks/).
![gridea-nederburg--index-demo](https://user-images.githubusercontent.com/26423989/56468065-aa16d200-6459-11e9-8b73-2f554809bded.png)
![gridea-nederburg-file-demo](https://user-images.githubusercontent.com/26423989/56468056-95d2d500-6459-11e9-931a-0fdefa2e2a0b.png)

[![点击预览](https://img.shields.io/badge/Preview-Gridea-red.svg)](https://www.suremotoo.site/)
<img src="https://img.shields.io/github/downloads/Suremotoo/gridea-nederburg-theme/total.svg?style=flat-square"/>
[![点击中文阅读](https://img.shields.io/badge/language-%E4%B8%AD%E6%96%87%E9%98%85%E8%AF%BB-ff69b4.svg)](https://github.com/Suremotoo/gridea-theme-nederburg/blob/master/README_zh.md)


## Development

Go to the directory where you have your Gridea site and run:
```shell
$ git clone https://github.com/Suremotoo/gridea-theme-nederburg.git
$ cd gridea-theme-nederburg
```
For more information read the official [dev guide](https://gridea.dev/docs/) of Gridea.

## Installation
1. Stop if your gridea program is running, please.
2. cd **<Your gridea's themes' dir>** && ``` git clone https://github.com/Suremotoo/gridea-theme-nederburg.git ```
3. start gridea app again & change nederburg & save

### 🥰🥰Enjoy!
