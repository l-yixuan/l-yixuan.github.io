images: 仅为开发主题时预览 avatar 所用
