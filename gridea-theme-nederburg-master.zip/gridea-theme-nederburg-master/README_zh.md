# 一个专门用于 Gridea 的 Nederburg 主题

Nederburg 是一个快速、漂亮的暗黑风格主题..

这个Gridea主题是从[competethemes](https://www.competethemes.com/tracks/)移植过来的.
![gridea-nederburg--index-demo](https://user-images.githubusercontent.com/26423989/56468065-aa16d200-6459-11e9-8b73-2f554809bded.png)
![gridea-nederburg-file-demo](https://user-images.githubusercontent.com/26423989/56468056-95d2d500-6459-11e9-931a-0fdefa2e2a0b.png)

[![Preview](https://img.shields.io/badge/%E7%82%B9%E5%87%BB%E9%A2%84%E8%A7%88%E6%95%88%E6%9E%9C-Gridea-red.svg)](https://www.suremotoo.site/)
<img src="https://img.shields.io/github/downloads/Suremotoo/gridea-nederburg-theme/total.svg?style=flat-square"/>
[![Read](https://img.shields.io/badge/language-English-ff69b4.svg)](https://github.com/Suremotoo/gridea-theme-nederburg/blob/master/README.md)


## 开发

进入到Gridea的主题目录，执行如下命令:
```shell
$ git clone https://github.com/Suremotoo/gridea-theme-nederburg.git
$ cd gridea-theme-nederburg
```
更多详情请参考Gridea开发文档 [dev guide](https://gridea.dev/docs/).

## 安装
1. 如果Gridea正在运行，请先关闭.
2. 进入 **<你的Gridea主题文件夹>** 然后执行 ``` git clone https://github.com/Suremotoo/gridea-theme-nederburg.git ```
3. 重新启动Gridea，在「主题」菜单中选择 「nederburg」，点击保存！

### 🥰🥰Enjoy!
